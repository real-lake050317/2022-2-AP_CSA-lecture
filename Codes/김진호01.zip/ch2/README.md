# Aug26 - Homework #1

ToDo: 

1. Make Student Class
2. Construct Student Object
3. Print Student's attribute values


File Systems:

Person.java: Abstract class for Student.java

Student.java: Child Class of Person.java, has age, name, height attribute, getter & setter for all 3 attributes.

StudentTest.java: Executes features using student class, gets input using scanner, constructs and prints attributes
