package Codes.ch5.Autoboxing.ex5;

public class ex5 {
    public static void main(String[] args) {
        Integer intOb1 = 4;
        Integer intOb2 = 8;
        if (intOb1 < intOb2) {
            System.out.println("True");
        } else {
            System.out.println("False");
        }
    }
}
