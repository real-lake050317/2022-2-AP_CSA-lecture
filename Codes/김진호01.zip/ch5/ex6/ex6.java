package Codes.ch5.Autoboxing.ex6;

public class ex6 {
    public static void main(String[] args) {
        Integer intOb1 = 4; //boxing
        int n = 8;
        if (intOb1 < n) {
            System.out.println("True");
        } else {
            System.out.println("False");
        }
    }
}
