package Codes.ch5.Autoboxing.ex3;

public class ex3 {
    public static void main(String[] args) {
        Integer intOb1 = 4; //boxing
        int n = 4;
        if (intOb1 == n) {
            System.out.println("True");
        } else {
            System.out.println("False");
        }
    }
}
