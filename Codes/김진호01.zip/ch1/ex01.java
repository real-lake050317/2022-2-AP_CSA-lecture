public class ex01 {

	public ex01() {
		// TODO Auto-generated constructor stub
	}
	
	//Problem 1 did not need to be implemented
	
	public static void problem2() {
		System.out.println("\\* This is not \n a comment *\\");
	}
	public static void problem3() {
		int n = 0;
		int x = 15;
		if (n != 0 && x / n > 100) 
			System.out.println("statment1");
		else
			System.out.println("statement2");
	}
	public static void problem4() {
		double answer = (double) (13 / 5);
		System.out.println("13 / 5 = " + answer);
	}
	public static void problem5() {
		int result = 13 - 3 *6 / 4 % 3;
		System.out.println(result);
	}
}