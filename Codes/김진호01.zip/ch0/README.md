# Sep01 - Homework #2

ToDo:

1. Make Student Class
2. Make array of Students, more than length of 22
3. Get input of Students' name, age, height, quiz score, midterm score, final exam score using text file
4. Compute students' final score composed with percentile of 30% midterm, 30% final, 40% quiz score
5. Return text output with data of students, aligned with final score.

File Systems:

Student.java: Has attribute of name, height, age, and three scores. Also has getter & setter for all attributes.

Sep01.java: Reads data from input.txt, makes array of Student objects, aligns the data with final score.

input.txt: Gives student data to Sep01.java, consists of name, age, height, scores.

result.txt: Output of Sep01.java after execution.

chn/ : directory of chn.utils, has 5 class files that is usable in reading and writing text files.
